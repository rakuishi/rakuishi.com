<?php
/*
Plugin Name: LinkShare To PHG
Plugin URI: http://rakuishi.com/wordpress/5886/
Description: This plugin replaced linkshare link with phg link. <strong>Please Change Affiliate Token Value from Settings.</strong>
Version: 1.0.2
Author: rakuishi
Author URI: http://rakuishi.com
License: Released under the GPL license
*/

define("LINKSHARE_TO_PHG_AFFILIATE_TOKEN_VALUE", "Linkshare_To_PHG_Affiliate_Token_Value");

// 投稿本文出力前の the_content をフックする
add_filter('the_content', 'linkshare_to_phg_content_filter');

function linkshare_to_phg_content_filter($content) {

	$affiliate_token = get_affiliate_token_value();

	// v1.0.2 以降
	$pattern = '|"http://click.linksynergy.com/.*?itunes.*?id([0-9]+)?%253.*?mt%253D([0-9]+)?%252.*?"|';
	$replacement = '"https://itunes.apple.com/jp/app/id$1?mt=$2&uo=4&at=' . $affiliate_token . '"';

	// v1.0.1 以前
	// $pattern = '|"http://click.linksynergy.com/.*?itunes.*?id([0-9]+)?%253.*?"|';
	// $replacement = '"https://itunes.apple.com/jp/app/id$1?mt=8&uo=4&at=' . $affiliate_token . '"';

	return preg_replace($pattern, $replacement, $content);
}

// 管理画面にメニューをフックする
add_action('admin_menu', 'linkshare_to_phg_admin_menu');

function linkshare_to_phg_admin_menu() {
	// 設定 -> LinkShare To PHG
	add_options_page (
		'LinkShare To PHG',
		'LinkShare To PHG',
		'administrator',
		'linkshare_to_phg_admin_menu',
		'linkshare_to_phg_setting'
	);
}

function linkshare_to_phg_setting() {

	if (isset($_POST['affiliate_token'])) {
		update_option(LINKSHARE_TO_PHG_AFFILIATE_TOKEN_VALUE, $_POST['affiliate_token']);
	}
	$affiliate_token = get_affiliate_token_value();

	echo <<<EOD
<div class="wrap">
    <div id="icon-options-general" class="icon32"><br /></div>
    <h2 id="wmpp-title">LinkShare To PHG</h2>
    <div class="wrap_form">
		<form action="" method="post">
			<label for="affiliate_token">アフィリエイト・トークン: </label> <input type="text" name="affiliate_token" value="{$affiliate_token}" size="10" />
			<input type="submit" class="button-primary" value="変更を保存" />
		</form>
	</div>
</div>
EOD;
}

function get_affiliate_token_value() {
	$affiliate_token = get_option(LINKSHARE_TO_PHG_AFFILIATE_TOKEN_VALUE);
	if ($affiliate_token == FALSE) {
		$affiliate_token = '11l3RT';
	}
	return $affiliate_token;
}

// スタイルシートを読み込むために、admin_head をフックする
if(isset($_GET['page']) && ($_GET['page'] === 'linkshare_to_phg_admin_menu')) {
	add_action('admin_head', 'linkshare_to_phg_admin_head');
}

function linkshare_to_phg_admin_head() {
	$path = plugin_dir_url(__FILE__); // 一番後ろに / が含まれている
	echo "<link rel='stylesheet' href='{$path}linkshare-to-phg-style.css' type='text/css' media='all' />\n";
}
